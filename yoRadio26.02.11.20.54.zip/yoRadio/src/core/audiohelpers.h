#pragma once

void hexDump(const char *label, const char *s);
