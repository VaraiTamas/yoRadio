#ifndef dsfont_h
#define dsfont_h

#ifdef CLOCKFONT_MONO
  #include "DS_DIGI15pt7b_mono.h"
#else
  #include "DS_DIGI15pt7b.h"
#endif

#endif
